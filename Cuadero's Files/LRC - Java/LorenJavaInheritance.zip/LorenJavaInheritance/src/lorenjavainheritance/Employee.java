package lorenjavainheritance;

public class Employee {
    public String name = "Employees Salary";
    
    public String getDetails()
    {
       return(name);
    }
}

