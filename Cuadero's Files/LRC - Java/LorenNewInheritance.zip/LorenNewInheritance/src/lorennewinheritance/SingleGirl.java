
package lorennewinheritance;

public class SingleGirl {
    public int BusinessAsset = 300000;
}
