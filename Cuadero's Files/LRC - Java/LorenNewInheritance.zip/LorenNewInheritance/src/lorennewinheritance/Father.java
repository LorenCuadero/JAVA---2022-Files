package lorennewinheritance;
public class Father extends GrandFather {
    public int FatherAssets = 200000;
    
    public double Share (double wife)
    {
        double wify = FatherAssets - wife;
        return wify;
    }
     public double Share(float wify, float numOfChildren)
        {
            double parting = ((asset-wify) / numOfChildren);
            return parting;
        }
}
