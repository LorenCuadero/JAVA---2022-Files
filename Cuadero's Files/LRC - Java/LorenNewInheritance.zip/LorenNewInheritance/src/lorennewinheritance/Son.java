package lorennewinheritance;

public class Son extends Father  {
        
}
