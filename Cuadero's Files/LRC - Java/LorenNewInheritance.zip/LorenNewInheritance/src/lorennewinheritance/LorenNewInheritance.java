
package lorennewinheritance;
import lorennewinheritance.*;
import IO.*;
public class LorenNewInheritance {

    public static void main(String[] args) {
       Son s = new Son();
       ConsoleInput i = new ConsoleInput();
       
       System.out.println("             Asset Division of Mondragon's Family");
       System.out.println("_______________________________________________________________\n");
       System.out.println("Sr. Mondragon's Total Asset $ " + s.asset);
       System.out.println("_______________________________________________________________\n");
       System.out.println("Fortunately, Mrs. Mondragon is still alive.\nAccording to the law, she can also have the share\nsince she holds a legal heir certificate such as\nMarriage Contract.");
       System.out.println("\nTherefore, Mrs. Mondragon can still have a \nshare of at least 50% of her husbands asset.");
       System.out.println("_______________________________________________________________\n");
       System.out.println("Mondragon's Wife Total Share $ " + s.Share(500000));
       System.out.println("_______________________________________________________________\n");
       System.out.println("Sr. and Mrs. Mondragon has 2 children: ");
       System.out.println("\nMondragon's Son Total Share $ " + s.Share(500000, 2));
       System.out.println("Mondragon's Daughter Total Share $ " + s.Share(500000, 2));
       System.out.println("_______________________________________________________________\n");
       System.out.println("As their children grew up, they build their own families.");
       System.out.println("_______________________________________________________________\n");
       System.out.println("Jr. Mondragon's Total Assets $ " +( s.Share(500000, 2) + s.FatherAssets));
       System.out.println("He got married yet both died and left their only child with all their assets: ");
       System.out.println("\nFurthermore his only child has the total asset: " +( s.Share(500000, 2) + s.FatherAssets));
       System.out.println("_______________________________________________________________\n");
       System.out.println("Meanwhile thier daughter remains single and live as a \nbusinesswoman with a total asset: " + (s.Share(500000, 2) + s.BusinessAsset));
       System.out.println("_______________________________________________________________\n");
       System.out.println(" And they lived Peacefully and Harmonously\n");











       

       


    }

}
