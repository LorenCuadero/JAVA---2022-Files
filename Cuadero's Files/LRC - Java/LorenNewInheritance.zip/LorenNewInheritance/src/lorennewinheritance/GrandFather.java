package lorennewinheritance;

public class GrandFather extends SingleGirl{
    public int asset = 1000000;
         public double Share(int Granny)
        {
           double part = asset-Granny;
            return part;
        }
        public double Share(float Granny, float numOfChildren)
        {
            double parts = ((asset-Granny) / numOfChildren);
            return parts;
        }

}
