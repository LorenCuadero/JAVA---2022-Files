package lorenio;

public class LorenIO {

    public static void main(String[] args) {
        
    }
    
}
