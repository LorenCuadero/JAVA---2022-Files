package IO;
import java.util.Scanner;
public class ConsoleInput {
    Scanner s = new Scanner(System.in);
    
    public double getNum()
    {
        return s.nextDouble();
    }
}
