package ValPass;

public class VP {
    public double difference(VP2 val)
    {
        double a = val.num1;
        double b = val.num2;
        
      return a-b;
        
    }
}

