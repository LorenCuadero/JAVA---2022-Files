package ValPass;

public class VP2 {
    public double num1;
    public double num2;
    
}
