package OP;
public class Operator1 {
     public double increment (double num1)
    {
       return (++num1);
     }
    public double decrement (double num1)
    {
       return (--num1);
     }
    public double  positivevalue (double num1, double num2)
    {
       return (num1 += num2);
     }
    public double negativevalue (double num1, double num2)
    {
       return (num1 -= num2);
     }
    public double productvar(double num1, double num2)
    {
       return (num1 *= num2);
     }
    }

