package BebieCalc1;

public class Output {
      public void show(Object value)
        {
            System.out.println(value);
        }
}
