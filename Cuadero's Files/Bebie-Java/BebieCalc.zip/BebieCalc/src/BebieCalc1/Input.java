package BebieCalc1;
import java.util.Scanner;
public class Input {
    Scanner s = new Scanner(System.in);

     public double getNum()
    {
        return s.nextDouble();
    }
}
