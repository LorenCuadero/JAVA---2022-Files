package Operator;

public class MyOperator {
  static void myMethod() {
    System.out.println("Thank you and Have a nice day!!!");
  }

  public static void main(String[] args) {
    myMethod();
  }
}

