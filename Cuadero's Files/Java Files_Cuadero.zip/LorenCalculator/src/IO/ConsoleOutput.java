package IO;

public class ConsoleOutput {
        public void show(Object value)
        {
            System.out.println(value);
        }

}
